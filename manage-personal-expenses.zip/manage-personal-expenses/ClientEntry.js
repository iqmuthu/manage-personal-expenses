import React from 'react';
import ReactDOM from 'react-dom';
import PersonalContainer from './containers/personalContainer.jsx';
import { Provider } from 'react-redux';
import createStoreWithInitialState from './store/index.jsx';

let appInitState ={
  personalDetails :{
    personalInfo:[]
  }
};

let store = createStoreWithInitialState(appInitState);
ReactDOM.render(<Provider store={store}>
  <PersonalContainer />
  </Provider>, document.getElementById('personalExpenseNode')
);
