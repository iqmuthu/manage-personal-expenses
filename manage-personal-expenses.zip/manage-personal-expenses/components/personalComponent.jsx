import React from 'react';
import { addingBalanceInfo } from '../store/actions/personalAction.jsx';

export class PersonalComponentItem extends React.Component {
    constructor(props) {
        super(props);
        this.state ={
            showIncomeDetails : false,
            amtValue : 0,
            reasonDes :'',
            showDetails: false
        }
        this.addingPersonalDetails = this.addingPersonalDetails.bind(this);
        this.addingBalanceDetails = this.addingBalanceDetails.bind(this);
        this.onAmountField = this.onAmountField.bind(this);
    }
    addingPersonalDetails(isShow){
        this.setState({showIncomeDetails :isShow, showDetails: true});
    }
    removingDetails(key){
        let { personalDetails } = this.props;
        let { personalInfo } = personalDetails;
        personalInfo.splice(key,1);
        this.props.dispatch(addingBalanceInfo(personalInfo));
    }
    addingBalanceDetails(){
        const { reasonDes, amtValue, showIncomeDetails } = this.state;
        let { personalDetails } = this.props;
        let { personalInfo } = personalDetails;
        var today =  new Date();
        var dd= today.getDate();
        var mm = today.getMonth()+1;
        var yyyy = today.getFullYear();
        let date = dd+'.'+mm+'.'+yyyy;
        let param ={
            date,
            amount : amtValue,
            reason : reasonDes,
            isIncome : showIncomeDetails
        };
        this.setState({showDetails:false});
        personalInfo.push(param);
        this.props.dispatch(addingBalanceInfo(personalInfo));
    }
    onReasonField(event){
        this.setState({reasonDes :event.target.value});
    }
    onAmountField(event){
        this.setState({amtValue :event.target.value});
    }
    render() {
        const incomeStyles = {
            color: 'white',
            backgroundColor: 'green',
            marginRight : '20px'
        };
        const spendingStyles = {
            color: 'white',
            backgroundColor: 'red'
        };
        const styles = {
            color: '#000',
            ':hover': {
                backgroundColor: '#0074d9'
            }
        };
        let { personalDetails } = this.props;
        let { personalInfo } = personalDetails;

       personalInfo =[
            {
                date: '21/05/2018',
                amount : 2500,
                reason : 'Groceries from Mani',
                isIncome : false
            },
            {
                date: '11/05/2018',
                amount : 5000,
                reason : 'Salary from work',
                isIncome : true
            },{
                date: '20/05/2018',
                amount : 2000,
                reason : 'New shirt from Saravana Store',
                isIncome : false
            }
        ];

        let totIncome = 0;
        let totSpends = 0 ;
        let totalIncome= personalInfo.map((item)=>{
            if(item.isIncome) {
                totIncome += parseInt(item.amount);
            } else {
                totSpends +=parseInt(item.amount);
            }
        });
        const { showIncomeDetails, showDetails } = this.state;
        return(
            <div style={{width:'450px'}}>
                <div style={{backgroundColor:'#9e9e9e47'}}>
                    <h2> Balance </h2>
                    <div>{totIncome-totSpends} CZK </div>
                    <div>
                        <span style={{color:'green'}}> Income : {totIncome} kc </span> <span style={{color:'red'}}>Spendings : { totSpends } Kc </span>
                    </div>
                </div>
                { showDetails && <div style={{marginBottom : '20px'}}>
                    <h3>Adding Details</h3>
                    <div><span>Amount</span><span style={{marginLeft:'126px'}}>Reason</span></div>
                    <div><input onChange={(e)=>this.onAmountField(e)} type='text'/> <input type='text' onChange={(e)=>this.onReasonField(e)}/> <button onClick={()=>this.addingBalanceDetails()}>Add</button></div>
                </div> }
                <div style={{marginTop : '20px'}}>
                    <div>
                    {
                        personalInfo && personalInfo.map((item, key)=>{
                            const redStyles = {
                                color: 'red'
                            };
                            const greenStyles = {
                                color: 'green'
                            };
                            return(
                                <div key={key}>
                                    <div>
                                        {item.date}
                                    </div>
                                    <div>
                                        <span style={item.isIncome ? greenStyles : redStyles}>{item.amount} Kc</span>
                                        <span style={{marginLeft:'70px'}}> {item.reason} </span>
                                        <a onClick={()=>this.removingDetails(key)} style={{float:'right',cursor:'pointer'}}>Remove</a>
                                    </div>
                                    <hr/>
                                </div>
                            )
                        })
                    }
                    </div>
                </div>
                <button onClick={()=>this.addingPersonalDetails(true)} style={incomeStyles}>Add Income</button>
                <button onClick={()=>this.addingPersonalDetails(false)} style={spendingStyles}>Add Spending</button>
            </div>
        );
    }
}
export default PersonalComponentItem;
