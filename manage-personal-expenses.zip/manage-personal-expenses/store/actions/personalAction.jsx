export const addingBalanceInfo =(personalInfo) =>{
	return (dispatch) => {
		dispatch({type:'UPDATE_BALANCE_INFO', payload: personalInfo});
	};
}