
const initialState = {
	personalInfo:[]
};
export default function(state = initialState, action) {
	let { type, payload} = action;
	switch (type) {
	case 'UPDATE_BALANCE_INFO':
		return Object.assign({}, state, {personalInfo: payload});
	default: return state;
	}
}